# MoEscope

**See how sparse routing becomes GPU work.**

MoEscope is an open-source lab for tracing, replaying, visualizing, and profiling
Mixture-of-Experts (MoE) inference workloads.

The project follows one question from model semantics down to hardware:

> When an MoE router sends a different number of tokens to each expert, what
> work does that create on the GPU, where is time wasted, and what evidence
> would justify changing the implementation?

MoEscope is currently in **Phase 1: routing foundations**. The first
hand-checkable trace and validation slice exists; model capture, workload
compilation, GPU replay, and performance results do not.

**Research journal:** [moescope.pages.dev](https://moescope.pages.dev/)<br />
**First note:** [From Inkling to silicon](https://moescope.pages.dev/writing/from-inkling-to-silicon/)
<br />
**Phase 1 guide:** [From router scores to a trustworthy trace](docs/phase-1.md)

## Why this project exists

An MoE layer does not run every feed-forward expert for every token. A learned
router chooses a small subset of experts, which reduces the amount of active
computation while increasing the model's total capacity.

That conditional computation creates a systems problem:

1. tokens choose experts;
2. the number of tokens assigned to each expert changes at runtime;
3. those assignments become a group of differently sized matrix
   multiplications;
4. GPU kernels must schedule that irregular work efficiently.

Batch size alone does not describe this workload. Two decode steps with the
same number of tokens can produce very different expert histograms and
therefore different tile counts, padding, waves, and latency.

This is an active area rather than an untouched research problem.
[RaMP](https://arxiv.org/abs/2604.26039) directly studies routing-aware kernel
selection, while [FlashInfer-Bench](https://github.com/flashinfer-ai/flashinfer-bench)
provides trace-driven kernel benchmarking infrastructure. MoEscope will not
present their ideas as new. Its initial contribution is a legible,
reproducible bridge between:

- the router decisions made by a real model;
- the expert workloads those decisions create;
- the GPU schedule used to execute them;
- the correctness and performance measurements produced by experiments.

Any optimization work will follow profiling. It is not predetermined.

## What we are building

MoEscope is designed as one pipeline with one direction of truth:

```mermaid
flowchart LR
    A["MoE model run"] --> B["Normalized routing trace"]
    B --> C["Workload compiler"]
    C --> D["Reference and kernel backends"]
    D --> E["Versioned result bundle"]
    B --> F["Interactive trace explorer"]
    C --> F
    E --> F
```

### 1. Routing tracer

The tracer will capture the routing decisions required to reconstruct a
workload:

- model and revision;
- prompt or dataset provenance;
- prefill or decode phase;
- layer and generation step;
- token positions;
- selected expert IDs and routing weights;
- routed and shared expert semantics;
- routing rule and normalization behavior;
- model dimensions and data type;
- software and hardware environment.

The normalized trace, not a notebook or visualization-specific payload, will
be the source of truth.

### 2. Workload compiler

The compiler will convert routing decisions into explicit expert workloads:

- tokens per expert;
- active and inactive experts;
- grouped-GEMM shapes;
- tile counts for a selected kernel configuration;
- padding and quantization waste;
- estimated CTA waves.

The output will be deterministic and testable. Adapters may export benchmark
cases compatible with the
[FlashInfer Trace schema](https://huggingface.co/datasets/flashinfer-ai/flashinfer-trace),
but MoEscope will preserve the model-level information that a kernel-only
trace does not represent.

### 3. Replay and benchmark harness

Every optimized path needs a correctness oracle. The first backends will be:

1. a straightforward PyTorch reference;
2. Triton's official static
   [grouped-GEMM design](https://triton-lang.org/main/getting-started/tutorials/08-grouped-gemm.html);
3. later experimental variants, added only to answer a measured question.

Benchmark results will record:

- input trace and workload hashes;
- Git commit;
- GPU, driver, CUDA, PyTorch, and Triton versions;
- kernel configuration;
- warmup and measurement procedure;
- latency distribution rather than a single best number;
- correctness tolerances and failure details.

### 4. Interactive explorer

The browser experience will connect three views of the same event:

- **Routing:** which tokens selected which experts?
- **Work:** what matrix shapes, tiles, and CTA waves did that produce?
- **Evidence:** how did the measured backends perform, and on what hardware?

The goal is for a systems engineer to inspect the evidence and for a newcomer
to understand the problem without pretending the two audiences need different
underlying data.

### 5. Profiler-led experiment

After the baseline is reproducible, MoEscope will choose one bounded question.
Examples include:

- when does routing skew change the best static Triton configuration?
- which histogram features predict tile or wave waste?
- where does the dispatch or preprocessing overhead dominate expert compute?
- how portable is a configuration decision across Ampere and Hopper?

These are candidate experiments, not promised conclusions. A negative result
with a clear explanation is a valid outcome.

## What makes the project useful

The project is successful if it produces evidence another person can inspect
and reproduce. It does not need to become a production inference engine.

The intended public artifacts are:

- a documented routing-trace format;
- a small, redistributable trace fixture;
- trace capture and validation tools;
- a deterministic workload compiler;
- reference and Triton benchmark backends;
- correctness and benchmark reports;
- an interactive web explainer;
- a technical article series;
- a final demo video and reproducible release.

## Non-goals

MoEscope will not initially:

- implement a complete inference server;
- train a new foundation model;
- claim a universal best MoE kernel;
- reproduce every FlashInfer, vLLM, or TensorRT-LLM backend;
- start with multi-node expert parallelism;
- report unverified speedups;
- hide losing workload regions or unsupported hardware.

These boundaries keep the project small enough to understand and finish.

## Evidence contract

Performance work is unusually easy to overstate. MoEscope follows these rules:

1. **Correctness before speed.** Optimized outputs are checked against the
   reference on fixed and randomized cases.
2. **Real and synthetic workloads.** Synthetic distributions isolate a
   variable; real traces test whether it matters in practice.
3. **Pinned environments.** Results identify the exact code, dependencies,
   GPU, and configuration.
4. **Distributions over hero numbers.** Reports include repeated measurements
   and variability.
5. **Win and loss regions.** A faster result is always scoped to the shapes and
   hardware where it was observed.
6. **No novelty by omission.** Closely related systems and papers are named
   explicitly.
7. **Artifacts over screenshots.** Plots and demos must be derivable from
   checked-in or released data.

## Roadmap

### Phase 0 — Foundation

**Question:** What exactly are we building, and what would count as credible?

- [x] Define the project thesis and non-goals.
- [x] Separate model traces, compiled workloads, and benchmark results.
- [x] Establish the evidence contract.
- [x] Publish the initial repository.
- [x] Publish the Phase 1 technical guide.

### Phase 1 — From router logits to a trustworthy trace

**Question:** Can we capture and validate the workload created by one MoE
forward pass?

Planned output:

- a minimal versioned routing-trace schema;
- a tiny four-expert reference example that can run without CUDA;
- an OLMoE trace-capture path;
- support for arbitrary top-k and shared experts without pretending shared
  execution was selected by the router;
- invariants and golden tests;
- a CLI that validates and summarizes a trace;
- the first article: *From token routing to expert histograms*.

Checkpoint 1 is complete:

- [x] create a dependency-light Python package and locked test environment;
- [x] define the first versioned routed/shared trace slice;
- [x] check in a canonical four-token, four-expert, top-2 fixture;
- [x] validate selection width, ranges, uniqueness, finite weights, and schema
  fields;
- [x] derive the expected `[2, 2, 3, 1]` routed histogram deterministically;
- [ ] generate the same trace from tensor operations;
- [ ] capture and validate a real OLMoE routing event.

Phase 1 is complete when a fresh checkout can produce or load a trace, validate
its invariants, and answer:

- how many tokens were routed at each layer?
- how many experts did each token select?
- how many tokens reached each expert?
- which work came from routed experts versus always-active shared experts?
- do routing weights and expert IDs have valid shapes and ranges?
- can the same trace summary be reproduced deterministically?

### Phase 2 — From trace to GPU workload

**Question:** How do expert histograms become grouped matrix multiplication?

- compile traces into expert GEMM shapes;
- calculate tiles, padding, and theoretical waves;
- validate the calculation with small hand-worked examples;
- ship the first interactive routing and workload explorer;
- publish: *How sparse routing becomes GPU work*.

### Phase 3 — Correct replay and static baseline

**Question:** Can we replay the same workload correctly and measure it without
fooling ourselves?

- implement the PyTorch oracle;
- reproduce a static Triton grouped-GEMM baseline;
- add randomized correctness tests;
- define the benchmark protocol and result bundle;
- run the first pinned A100 experiment;
- publish: *Benchmarking irregular GPU workloads honestly*.

### Phase 4 — Profiling and one experiment

**Question:** What does profiling show is actually worth changing?

- capture Nsight Systems and Nsight Compute evidence;
- select one bounded hypothesis;
- implement the smallest experiment that can falsify it;
- evaluate real and synthetic traces on defined hardware;
- report wins, losses, overhead, and limitations;
- publish the experiment and its failed attempts.

### Phase 5 — Public release

**Question:** Can another engineer understand, run, and challenge the work?

- harden installation, CI, documentation, and examples;
- release a versioned trace and result set;
- finish the interactive site;
- publish the final technical report;
- record a concise demo video;
- identify a genuinely useful upstream issue, adapter, or contribution.

## Compute and deployment

Development uses two intentionally different environments.

### GPU experiments: Modal

CUDA and Triton kernel work needs direct access to NVIDIA hardware. Modal
currently exposes selectable A100, H100, H200, and other GPU types through
custom container images and bills by active compute time. Its starter plan
currently includes monthly compute credit.

The initial benchmark target will be a pinned `A100-40GB`. Cross-architecture
validation can add a pinned `H100!` run later; Modal's explicit pin avoids an
automatic H200 upgrade that would make comparisons ambiguous.

See [Modal GPU documentation](https://modal.com/docs/guide/gpu) and
[current pricing](https://modal.com/pricing).

### Public application and artifacts: Cloudflare

Cloudflare is a good fit for the eventual public surface:

- Cloudflare Pages for the Astro + MDX interactive site;
- R2 for released traces, plots, profiles, and result bundles;
- optional D1 for a small searchable result index.

It is not the kernel-development environment. Cloudflare Workers AI provides
managed inference on a model catalog, while the documented Container instance
types expose CPU, memory, and disk rather than an attachable CUDA GPU. That
does not provide the low-level NVIDIA environment required for custom Triton
kernels and Nsight profiling.

See [Cloudflare Container limits](https://developers.cloudflare.com/containers/platform-details/limits/)
and the [Workers AI model catalog](https://developers.cloudflare.com/workers-ai/models/).

## Phase 1 learning path

Read in this order. The goal is not to finish every page before writing code;
it is to build the vocabulary needed for the next experiment.

### A. Understand the model operation

1. Read the routing and architecture portions of the
   [OLMoE paper](https://arxiv.org/abs/2409.02060).
2. Inspect the [OLMoE repository](https://github.com/allenai/OLMoE), especially
   its routing-analysis scripts and model configuration.
3. Read Hugging Face's
   [OLMoE implementation](https://github.com/huggingface/transformers/tree/main/src/transformers/models/olmoe)
   far enough to locate router logits, top-k selection, and expert execution.

You should be able to explain:

- why total parameters and active parameters differ;
- what top-k routing returns for one token;
- the shapes of router logits, selected expert IDs, and routing weights;
- the difference between routing balance and expert specialization.

### B. Understand the workload representation

1. Work through a toy example with four tokens, four experts, and top-2
   routing by hand.
2. Read the
   [FlashInfer Trace overview](https://huggingface.co/datasets/flashinfer-ai/flashinfer-trace).
3. Skim the [FlashInfer-Bench repository](https://github.com/flashinfer-ai/flashinfer-bench)
   to understand its Definition, Workload, Solution, and Trace concepts.

You should be able to explain:

- which information belongs to a model routing trace;
- which information is sufficient to replay a kernel workload;
- why benchmark results must not be mixed into the input trace;
- which metadata is required for reproduction.

### C. Learn only the PyTorch needed for capture

Review:

- tensor shapes, indexing, `softmax`, and `topk`;
- forward hooks and model outputs;
- inference mode and deterministic seeds;
- JSON Lines or another streaming record format;
- unit tests for tensor invariants.

You should be able to take a small logits tensor, compute top-k routes, produce
an expert histogram, and verify the result by hand.

### D. Preview the hardware destination

Read only the introduction and scheduling idea in Triton's
[Group GEMM tutorial](https://triton-lang.org/main/getting-started/tutorials/08-grouped-gemm.html).
Do not optimize the kernel in Phase 1.

You should be able to explain why one expert histogram becomes a group of
matrix multiplications with different `M` dimensions.

## Planned repository shape

The layout will grow only when each component exists:

```text
moescope/
├── README.md
├── LICENSE
├── docs/
├── src/moescope/
│   ├── trace/
│   └── workloads/
├── tests/
├── examples/
├── web/
└── experiments/
```

The repository will not begin with empty scaffolding for future subsystems.

The public writing lives in `web/` as a normal Astro + MDX project. It has no
dependency on a proprietary site builder and can be developed locally with:

```bash
cd web
npm install
npm run dev
```

The static build is designed for deployment to Cloudflare Pages.

The current Python checkpoint can be reproduced with:

```bash
uv sync --dev
uv run pytest
uv run python examples/summarize_trace.py
```

## Writing and launch

The engineering record is part of the deliverable. Each phase should preserve
the decisions, failed assumptions, benchmark artifacts, and visuals needed for
an honest article.

The launch style is inspired by [mni.ml](https://mni-ml.github.io/): one clear
technical claim, an artifact people can try, open code, a thorough explanation,
and a short video that shows the system rather than merely describing it.

The final result should make three things obvious in under a minute:

1. routing varies at runtime;
2. that variation changes GPU work;
3. MoEscope makes the relationship inspectable and measurable.

## Prior art and starting points

- [OLMoE](https://github.com/allenai/OLMoE) — open model, checkpoints, code,
  logs, and routing analyses.
- [Inkling](https://thinkingmachines.ai/news/introducing-inkling/) — a
  frontier-scale example with 6-of-256 routed experts plus 2 shared experts;
  useful motivation and a future synthetic workload shape, not the Phase 1
  runtime.
- [Triton Group GEMM](https://triton-lang.org/main/getting-started/tutorials/08-grouped-gemm.html)
  — the initial static grouped-GEMM reference.
- [FlashInfer-Bench](https://github.com/flashinfer-ai/flashinfer-bench) and
  [FlashInfer Trace](https://huggingface.co/datasets/flashinfer-ai/flashinfer-trace)
  — trace-driven kernel evaluation and schema ideas.
- [RaMP](https://arxiv.org/abs/2604.26039) — routing-aware runtime selection
  and the closest overlap with the original optimization idea.
- [ScatterMoE](https://github.com/shawntan/scattermoe) — a compact Triton MoE
  implementation and useful comparison point.
- [NVIDIA Nsight Compute](https://docs.nvidia.com/nsight-compute/) — kernel
  profiling and roofline analysis.

## License

MoEscope is released under the [MIT License](LICENSE).
